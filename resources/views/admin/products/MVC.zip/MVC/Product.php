<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;


    // public function category()
    // {
    // 	return $this->belongsTo(Category::class,'category_id');
    // }

    // public function category()
    // {
    //     return $this->belongsTo('App\Category');
    // }


    public function productcategory()
    {
         return $this->belongsTo('App\Models\ProductCategory');
    }

    public function productcompany()
    {
        return $this->belongsTo('App\Models\ProductCompany');
    }

    public function measureunit()
    {
       return $this->belongsTo('App\Models\ProductMeasureunit');
    }


    protected $fillable = [

        'product_code',
        'product_name',
        'sku',
        'price_hint',
        'busy_price',
        'sell_price',
        'barcode',
        'product_category',
        'brand_name',
        'measure_unit',
        'opeing_stock',
        'warranty_period'



    ];
}
