<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\ProductCategory;
use App\Models\ProductCompany;
use App\Models\ProductMeasureUnit;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $Products = Product::all();
        return view('admin.products.index', compact('Products'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = ProductCategory::all();
       $campanies = ProductCompany::all();
       $measureunits = ProductMeasureUnit::all();

       return  view('admin.products.create', compact('categories', 'campanies', 'measureunits'));
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       $request->validate([

        'product_name' => 'required',
       'sku' =>'required',
        'busy_price' => 'required',
        'measure_unit' => 'required'

       ]);

       $product = new Product;
       $product->product_code = $request->product_code;
       $product->product_name = $request->product_name;
       $product->sku = $request->sku;
       $product->price_hint = $request->price_hint;
       $product->busy_price = $request->busy_price;
       $product->sell_price = $request->sell_price;
       $product->barcode = $request->barcode;
       $product->brand_name = $request->brand_name;
       $product->measure_unit = $request->measure_unit;
       $product->opeing_stock = $request->opeing_stock;
       $product->warranty_period = $request->warranty_period;
       $product->save();

       return redirect()->route('products.index')
       ->with('success', 'Product  Added successfully');
       



    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        //
    }
}
